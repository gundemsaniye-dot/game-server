# Castle Stormers Tiled workflow

`maps/*.tmj` and `tilesets/*.tsj` are the editable Tiled sources. Do not edit
`public/assets/tiled/maps/*.json`: those files are Phaser runtime output.

Commands:

- `npm run tiled:source` rebuilds the campaign's initial authored sources from
  the preserved legacy maps. Use this only when intentionally regenerating the
  baseline.
- `npm run tiled:build` embeds every external TSJ into runtime JSON and copies
  required tile images.
- `npm run tiled:validate` checks all 20 source/runtime maps, layer contracts,
  tile dimensions, GIDs, tileset images, deploy safety and reachability.

The required map contract is 32x18 orthogonal cells at 40px, with the twelve
named ground/navigation/object layers in the project plan. The invisible
`NAV_BLOCKED` layer is expanded to the runtime 64x36 navigation grid.
